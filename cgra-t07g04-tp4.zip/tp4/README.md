# CGRA 2020/2021

## Group T07G04

## TP 4 Notes

- In exercise 1 we learned how to apply textures to objects; 
- ![Screenshot 1](screenshots/cgra-t07g04-tp4-1.png)
- In exercise 2 we learned how to apply textures to a 3 dimensional cube and linear interpolation .
- ![Screenshot 2](screenshots/cgra-t07g04-tp4-2.png)